import React from 'react'

const ShowHospital = () => {
  return (
    <div>ShowHospital</div>
  )
}

export default ShowHospital