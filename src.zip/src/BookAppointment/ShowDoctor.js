import React from 'react'

const ShowDoctor = () => {
  return (
    <div>ShowDoctor</div>
  )
}

export default ShowDoctor