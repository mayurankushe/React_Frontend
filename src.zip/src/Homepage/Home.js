import React from 'react';
import './Home.css'
import {useNavigate} from 'react-router-dom'
import Footer from './Footer/Footer';
import { Link } from 'react-router-dom';
import DoctorDashboard from '../Dashboard/DoctorDashboard';
const Home=()=>
{
    const navigate = useNavigate();
    const bookAppointment=()=>
    {
        navigate.push("localhost:3000/login/patient")
    }
    return(
        <div>
            <div className='body'>
                
                <div class="row featurette container-fluid pt-3 pb-1 custom-height">
                    
                    <div class="col-md-9 mb-2 d-flex justify-content-center align-items-center">
                   
                    <div className='d-flex flex-column'>
                            <Link to="/login/patient" className='btn btn-primary rounded-pill px-5 mb-4 btn-lg'>Book appointment</Link>
                            <Link to='/' className='btn btn-secondary rounded-pill px-5 mb-4 btn-lg'>Buy Medicine</Link>
                            <Link to='/' className='btn btn-danger rounded-pill px-5 mb-4 btn-lg'>Book LabTest</Link>
                    </div> 
                    </div>
                    <div class="col-sm-2 mb-4">
                        <img src="doctor.png" alt="" width="Auto" height="80%"/>
                    </div>
                </div>
                <div>
                
                </div>
                {/* Middle Content Card code */}
                <div class="extra-margin-5 shadow px-5">
                    <div class="Container-fluid">
                    <h2>Doctors With Hospify</h2>
                        <div class="row justify-content-md-center">
                            
                            <div class="row mb-5">
                                <div class="col">
                                <div class="product-card mt-4">
                                    <div class="product-img img-one"></div>
                                        <div class="product-text">
                                            <h3>Dr. Kurkure</h3>
                                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt excepturi totam ducimus, nemo tenetur, quibusdam accusamus neque deserunt aliquid perferendis.</p>
                                        </div>
                                        <div class="product-cart">
                                            <button type="submit">Connect With Doctor</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                <div class="product-card mt-4">
                                    <div class="product-img img-one"></div>
                                        <div class="product-text">
                                            <h3>Dr. Desai</h3>
                                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt excepturi totam ducimus, nemo tenetur, quibusdam accusamus neque deserunt aliquid perferendis.</p>
                                        </div>
                                        <div class="product-cart">
                                            <button type="submit">Connect With Doctor</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                <div class="product-card mt-4">
                                    <div class="product-img img-one"></div>
                                        <div class="product-text">
                                            <h3>Dr. Roy</h3>
                                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt excepturi totam ducimus, nemo tenetur, quibusdam accusamus neque deserunt aliquid perferendis.</p>
                                        </div>
                                        <div class="product-cart">
                                            <button type="submit">Connect With Doctor</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                <div class="product-card mt-4">
                                    <div class="product-img img-one"></div>
                                        <div class="product-text">
                                            <h3>Dr. Ankushe</h3>
                                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt excepturi totam ducimus, nemo tenetur, quibusdam accusamus neque deserunt aliquid perferendis.</p>
                                        </div>
                                        <div class="product-cart">
                                            <button type="submit">Connect With Doctor</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                <div class="product-card mt-4">
                                    <div class="product-img img-one"></div>
                                        <div class="product-text">
                                            <h3>Dr. Ankushe</h3>
                                            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt excepturi totam ducimus, nemo tenetur, quibusdam accusamus neque deserunt aliquid perferendis.</p>
                                        </div>
                                        <div class="product-cart">
                                            <button type="submit">Connect With Doctor</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
               
            </div>
            
        
        <div class="custom-footer">
            <DoctorDashboard/>
        </div>
  

        <div class="custom-footer">
            <Footer/>
        </div>
    </div>
        
        
        
   )
}
export default Home;