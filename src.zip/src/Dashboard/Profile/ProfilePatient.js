import axios from 'axios';
import React , {useState , useEffect} from 'react'


const ProfilePatient = () => {

const[patient,setPatient] = useState([]);

useEffect(() => {

  getPatientDetails();
}, [])

const getPatientDetails = () => 
{
    axios.get("http://localhost:8080/dashboard/patient")
}


  return (
       <div>
         <button class=""></button>
           <h2 className="text-center mt-5">Patient Profile</h2>
           <table class="table table-striped table-hover">
  <thead>
    <tr>
        <th className="text-center" id='name'> Name</th>
        <th className="text-center" id='age'> Age</th>
        <th className="text-center" id='address'>Address</th>
        <th className="text-center" id='bloodGroup'>Blood-Group</th>
        <th className="text-center" id='email'>Email</th>
        <th className="text-center" id='mobileno'>MobileNo</th>
        <th className="text-center" id='actions'>Actions</th> 
    </tr>
  </thead>
  <tbody>
    {
        
    }
  </tbody>
</table>
       </div>
  )
}

export default ProfilePatient;