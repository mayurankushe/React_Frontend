import React from 'react'

const Treatment = () => {
  return (
    <div>Treatment</div>
  )
}

export default Treatment