import React from 'react';


const NotFound=()=>{
    return(
        <div>
            <h1 className='m-5 p-5'>Oops! That page can’t be found.</h1>
        </div>
    )
}
export default NotFound;