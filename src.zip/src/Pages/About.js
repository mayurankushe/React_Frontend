import React from 'react';


const About=()=>{
    return(
        <div>
            Hospify :
Hospify – Stay Home OPD has been developed by Centre for Development of Advanced Computing (C-DAC) in Mohali. Salient features of this citizen friendly web-based National Teleconsultation Service (eSanjeevaniOPD) are:

Patient registration
Token Generation
Queue Management
Audio-Video Consultation with a Doctor
ePrescription
SMS/Email Notifications
Serviced by State’s Doctors
Free Service
Fully configurable (no. of daily slots, no. of doctors/clinics, waiting room slots, consultation time limit etc).
        </div>
    )
}

export default About;